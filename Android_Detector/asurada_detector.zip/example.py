import pyyolo
import numpy as np
import sys
import cv2

darknet_path = './darknet'
datacfg = 'cfg/all.data'
#cfgfile = 'cfg/tiny-yolo.cfg'
cfgfile = 'cfg/yolo-all.cfg'
#weightfile = '../tiny-yolo_6200.weights'
#weightfile = '../yolo-all_12300.weights'
weightfile = darknet_path + '/tiny-yolo_49000.weights'
filename = darknet_path + '/data/dog.jpg'
thresh = 0.24
hier_thresh = 0.5
 
pyyolo.init(darknet_path, datacfg, cfgfile, weightfile)

capture0 = cv2.VideoCapture('f2.mp4')
capture1 = cv2.VideoCapture('b.mp4')
TotalSize= int(416)
out = cv2.VideoWriter('output.avi',cv2.VideoWriter_fourcc('M','J','P','G'), 10, (416,416))


while (1):
    ret0, frameFront = capture0.read()
    ret1, frameBackOrig = capture1.read()
    frameBack  = frameBackOrig[ 100 : frameBackOrig.shape[0] - 100, 200:frameBackOrig.shape[1] ]
    frameFront = cv2.resize(frameFront, (TotalSize, TotalSize), interpolation=cv2.INTER_AREA)
    frameBack_W=int(TotalSize/2)
    frameBack_H=int(TotalSize/2)
    frameBack  = cv2.resize(frameBack, (frameBack_W, frameBack_H), interpolation=cv2.INTER_AREA)

    cx= frameFront.shape[0]/2
    cy= frameFront.shape[1]/2
    w = frameFront.shape[0]/2
    h = frameFront.shape[1]/4

    t = int(TotalSize/2 - TotalSize/32)
    l = int(TotalSize/2 - TotalSize/4)
    b = int(TotalSize/2 + TotalSize/8 + TotalSize/16)
    r = int(TotalSize/2 + TotalSize/4)

    #cv2.rectangle(frameFront,(l, t),(r,b),255,5)
    frameROI = frameFront[t:b, l:r]
    frameROI_W=int(TotalSize/2+TotalSize/8)
    frameROI_H=int(TotalSize/2)
    frameROI = cv2.resize(frameROI, (frameROI_W, frameROI_H), interpolation=cv2.INTER_LANCZOS4)

    frameFront[0 : frameBack.shape[0], 0 : frameBack.shape[1]] = frameBack
    frameFront[0 : frameROI_H, TotalSize-frameROI_W: TotalSize] = frameROI
 
    img = frameFront.transpose(2,0,1)
    c, h, w = img.shape[0], img.shape[1], img.shape[2]
    # print w, h, c 
    data = img.ravel()/255.0
    data = np.ascontiguousarray(data, dtype=np.float32)
    outputs = pyyolo.detect(w, h, c, data, thresh, hier_thresh)	
    for output in outputs:
        cv2.rectangle(frameFront,(output['left'], output['top'] ),(output['right'],output['bottom'] ),(0,255,0),3)
        print(output['class'])

    #cv2.imshow('webcam', frameFront)
    out.write(frameFront)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break;

capture0.release()
capture1.release()

cv2.destroyAllWindows() 
pyyolo.cleanup()
