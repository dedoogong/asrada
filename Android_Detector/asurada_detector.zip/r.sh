sudo nvpmodel -m0
sudo ~/jetson_clock.sh
sudo rm -rf build
make -j
sudo rm -rf build
python3 setup_gpu.py build
sudo python3 setup_gpu.py install
